=== The City Login ===
Contributors: weshays
Tags: city, thecity, onthecity, login, acs
Requires at least: 2.8
Tested up to: 3.5.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A WordPress plugin that allows users to login directly to The City from your WordPress website.

== Description ==

A WordPress plugin that allows users to login directly to The City from your WordPress website.

== Installation ==

Install from within WordPress:
<br>
Go to Plugins => Add New => search for “the city login”.

Install manually:

    Unzip the file you downloaded.

    Upload files to a ‘the-city-login’ folder in the ‘/wp-content/plugins/’ directory.

    Log into your Wordpress admin and activate the plugin through the ‘Plugins’ menu.

    In the widgets screen drag the widget to the content section you want it to show up in.

    Set the fields as shown and then save.




== Frequently Asked Questions == 

= How do I get involved =

Visit our GitHub page and fork the project.
<br>
https://github.com/thecity/thecity-login-wordpress


= I found a bug =

Visit this projects GitHub page create an issue for the bug.
<br>
https://github.com/thecity/thecity-login-wordpress/issues


= I have a feature request =

Visit this projects GitHub page create an issue for the feature request.
<br>
https://github.com/thecity/thecity-login-wordpress/issues


== Screenshots ==

Here is the link to the description of the plugin:
http://developer.onthecity.org/thecity-plugins/wordpress-login/


== Upgrade Notice == 

None yet...


== Changelog ==

= 0.1 =
* Initial release of the Login-Wordpress plugin.
